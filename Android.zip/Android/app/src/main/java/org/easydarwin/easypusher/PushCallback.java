package org.easydarwin.easypusher;

/**
 * 推流状态的回调
 * */
class PushCallback {
    public final int code;

    public PushCallback(int code) {
        this.code = code;
    }
}
