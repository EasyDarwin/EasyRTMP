package org.easydarwin.bus;

/**
 * 停止录像的通知
 *
 * Created by apple on 2017/7/21.
 */
public class StopRecord {

}
