package org.easydarwin.bus;

/**
 * USB、前后置摄像头
 *
 * Created by apple on 2017/7/21.
 */
public class CameraId {
    private int mCameraId;

    public CameraId(int mCameraId) {
        this.mCameraId = mCameraId;
    }

    public int getmCameraId() {
        return mCameraId;
    }
}
