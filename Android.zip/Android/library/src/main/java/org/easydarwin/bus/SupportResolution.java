package org.easydarwin.bus;

/**
 * 获取可以支持的分辨率
 *
 * Created by apple on 2017/8/29.
 */
public class SupportResolution {

}
