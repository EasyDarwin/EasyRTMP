package org.easydarwin.bus;

/**
 * 开始录像的通知
 *
 * Created by apple on 2017/7/21.
 */
public class StartRecord {

}
